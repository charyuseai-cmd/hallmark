import { AppWindowMac, MousePointerClick, Rocket, X } from 'lucide-react';
import React, { useState } from 'react';
import { ScrollArea } from './ui/scroll-area';
import { usePathname, useRouter } from 'next/navigation';
import Link from 'next/link';
import { SidebarDrawer, DrawerContent } from './vaul-sidebar';
import { basePath } from './sidebar';
import { AllComponens } from '@/configs/docs';
import { cn } from '@/lib/utils';

function MobileHeader({ classname }: { classname?: string }) {
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  return (
    <>
      <button
        className={cn(classname, 'text-3xl')}
        onClick={() => setSidebarOpen(true)}
      >
        {/* <HiOutlineMenuAlt2 /> */}
        <svg
          width='642'
          height='421'
          viewBox='0 0 642 421'
          fill='none'
          xmlns='http://www.w3.org/2000/svg'
          className=' stroke-primary w-9 h-9'
        >
          <path
            d='M52.333 359H252.333'
            strokeWidth='66.6667'
            strokeLinecap='round'
          />
          <path
            d='M52.333 212H452.333'
            strokeWidth='66.6667'
            strokeLinecap='round'
          />
          <path
            d='M52.333 65H585.666'
            strokeWidth='66.6667'
            strokeLinecap='round'
          />
        </svg>
      </button>
      <SidebarDrawer
        open={sidebarOpen}
        setOpen={setSidebarOpen}
        direction={'left'}
        outsideClose={true}
        className='sm:w-72 w-[70%] p-4 h-screen '
      >
        <DrawerContent>
          <figure className='flex justify-between  w-full items-center'>
            <Link
              href='/'
              className='flex gap-2 items-center text-2xl font-semibold border-b  py-2'
            >
              <svg
                width='246'
                height='81'
                viewBox='0 0 246 81'
                className='w-36 h-full fill-primary stroke-primary'
                fill='none'
                xmlns='http://www.w3.org/2000/svg'
              >
                <path d='M29.096 48.704V50.688C29.096 50.7733 29.096 50.8587 29.096 50.944C29.224 51.6267 29.6293 51.968 30.312 51.968H52.136V63.936H22.312C21.3307 63.936 20.4773 63.5733 19.752 62.848C19.0267 62.1227 18.664 61.2693 18.664 60.288V34.688C18.664 33.664 19.0267 32.8107 19.752 32.128C20.4773 31.4027 21.3307 31.04 22.312 31.04H26.216C27.24 31.04 28.1147 30.6773 28.84 29.952C29.5653 29.2267 29.928 28.352 29.928 27.328V22.848C29.928 21.824 30.2693 20.9493 30.952 20.224C31.6773 19.4987 32.552 19.136 33.576 19.136H52.136V31.04H30.312C29.6293 31.04 29.224 31.3813 29.096 32.064C29.096 32.1493 29.096 32.2133 29.096 32.256V48.704ZM76.363 35.648H87.435V60.864C87.435 61.7173 87.115 62.464 86.475 63.104C85.8777 63.7013 85.1523 64 84.299 64H68.875C67.851 64 66.9763 63.6373 66.251 62.912C65.5257 62.1867 65.163 61.3333 65.163 60.352V57.152C65.163 56.256 64.9497 55.424 64.523 54.656C64.0963 53.888 63.499 53.2907 62.731 52.864C62.0057 52.3947 61.195 52.1387 60.299 52.096H57.611C56.6297 52.096 55.7763 51.7547 55.051 51.072C54.3257 50.3467 53.963 49.472 53.963 48.448V35.648H65.227V50.944C65.227 51.2427 65.3123 51.4987 65.483 51.712C65.6963 51.9253 65.9523 52.032 66.251 52.032H75.275C75.5737 52.032 75.8297 51.9253 76.043 51.712C76.2563 51.4987 76.363 51.2427 76.363 50.944V35.648ZM105.689 35.648H117.849V47.68H102.937C102.638 47.68 102.382 47.7867 102.169 48C101.956 48.1707 101.849 48.4053 101.849 48.704V64H90.777V51.2C90.777 50.176 91.1397 49.3227 91.865 48.64C92.5903 47.9147 93.4437 47.552 94.425 47.552H98.265C99.289 47.552 100.164 47.1893 100.889 46.464C101.614 45.7387 101.977 44.8427 101.977 43.776V39.36C101.977 38.6773 102.148 38.0587 102.489 37.504C102.83 36.9493 103.278 36.5013 103.833 36.16C104.388 35.8187 105.006 35.648 105.689 35.648ZM154.208 35.712V45.568H134.496L151.712 51.52C152.437 51.776 153.034 52.224 153.504 52.864C153.973 53.504 154.208 54.208 154.208 54.976V64H120.736V52.096H135.072L123.296 48.384C122.528 48.1707 121.909 47.744 121.44 47.104C120.97 46.4213 120.736 45.696 120.736 44.928V35.712H154.208ZM169.437 31.168H158.365V19.2H169.437V31.168ZM158.365 64V35.712H169.437V64H158.365ZM186.088 31.168C185.874 31.168 185.682 31.232 185.512 31.36C185.341 31.4453 185.213 31.5733 185.128 31.744C185.042 31.9147 185 32.0853 185 32.256V35.648H194.28C194.578 35.648 194.834 35.7547 195.048 35.968C195.261 36.1813 195.368 36.4373 195.368 36.736V46.464C195.368 46.7627 195.261 47.0187 195.048 47.232C194.834 47.4453 194.578 47.552 194.28 47.552H185V58.048V64H173.928V34.752C173.928 33.728 174.29 32.8747 175.016 32.192C175.741 31.4667 176.594 31.104 177.576 31.104H181.416C182.44 31.104 183.314 30.7413 184.04 30.016C184.765 29.248 185.128 28.352 185.128 27.328V22.848C185.128 21.8667 185.49 21.0133 186.216 20.288C186.941 19.5627 187.816 19.2 188.84 19.2H198.376V31.168H186.088ZM219.676 35.648H230.748V64.896C230.748 65.92 230.385 66.7947 229.66 67.52C228.934 68.2453 228.06 68.608 227.036 68.608H223.26C222.236 68.608 221.34 68.9707 220.572 69.696C219.846 70.4213 219.484 71.296 219.484 72.32V76.8C219.484 77.824 219.121 78.6773 218.396 79.36C217.713 80.0853 216.86 80.448 215.836 80.448H197.276V68.48H218.588C218.886 68.48 219.142 68.3733 219.356 68.16C219.569 67.9467 219.676 67.6907 219.676 67.392V65.088V64H212.188C211.164 64 210.289 63.6373 209.564 62.912C208.838 62.1867 208.476 61.3333 208.476 60.352V57.152C208.476 56.256 208.262 55.424 207.836 54.656C207.409 53.888 206.812 53.2907 206.044 52.864C205.318 52.3947 204.508 52.1387 203.612 52.096H200.924C199.942 52.096 199.089 51.7547 198.364 51.072C197.638 50.3467 197.276 49.472 197.276 48.448V35.648H208.54V50.944C208.54 51.2427 208.625 51.4987 208.796 51.712C209.009 51.9253 209.265 52.032 209.564 52.032H218.588C218.886 52.032 219.142 51.9253 219.356 51.712C219.569 51.4987 219.676 51.2427 219.676 50.944V35.648Z' />
                <path
                  d='M18.6055 27.2686L2 24.6406'
                  strokeWidth='3'
                  strokeLinecap='round'
                />
                <path
                  d='M21.9606 22.5695L8.89062 10.5107'
                  strokeWidth='3'
                  strokeLinecap='round'
                />
                <path
                  d='M26.8882 17.6789L20.0938 1.70215'
                  strokeWidth='3'
                  strokeLinecap='round'
                />
                <path d='M245.245 7.89666L235.068 33.4694C234.724 34.3342 233.489 34.301 233.192 33.4189L231.612 28.732L230.773 26.2418C230.573 25.6477 229.882 25.3822 229.336 25.6893L222.429 29.5714L221.571 29.1429L220.714 28.2857L225.319 20.6779C225.618 20.1828 225.436 19.5375 224.922 19.2718L222.582 18.0619L218.23 15.8126C217.427 15.3975 217.543 14.2143 218.412 13.9635L244.039 6.56614C244.838 6.33552 245.553 7.12404 245.245 7.89666Z' />
              </svg>
            </Link>

            <button
              className='md:hidden flex'
              onClick={() => setSidebarOpen(false)}
            >
              <X />
            </button>
          </figure>
          {/* <GitHubButton /> */}

          <ScrollArea className='h-[95%] py-4 pb-12'>
            <ul className='pb-3'>
              {basePath?.map((link, index) => {
                return (
                  <>
                    <li key={`id-${index}`}>
                      <Link
                        href={link.href}
                        onClick={() => setSidebarOpen(false)}
                        className={`flex gap-2 group font-medium items-center py-1  transition-all ${
                          link.href === pathname
                            ? 'active-nav'
                            : 'text-slate-600 hover:text-slate-900  dark:text-slate-400 dark:hover:text-white'
                        }`}
                      >
                        {React.cloneElement(link?.icon, {
                          className: `${
                            link.href === pathname
                              ? 'dark:text-black dark:bg-white bg-black text-white'
                              : 'dark:bg-zinc-800 dark:text-white group-hover:bg-black group-hover:text-white  dark:group-hover:bg-white dark:group-hover:text-black'
                          } h-7 w-7 border transition-all  rounded-sm p-1.5`,
                        })}

                        {link.componentName}
                      </Link>
                    </li>
                  </>
                );
              })}
              {[
                {
                  name: 'tools',
                  url: 'https://tools.ui-layouts.com/',
                  icon: <AppWindowMac />,
                },
                {
                  name: 'cursify',
                  url: 'https://cursify.ui-layouts.com/',
                  icon: <MousePointerClick />,
                },
              ].map((item, index) => {
                return (
                  <>
                    <li key={`id-${index}`}>
                      <a
                        href={item.url}
                        target='_blank'
                        className='flex gap-2 group font-medium items-center py-1  transition-all'
                      >
                        {React.cloneElement(item?.icon, {
                          className: `${'dark:bg-zinc-800 dark:text-white group-hover:bg-black group-hover:text-white  dark:group-hover:bg-white dark:group-hover:text-black'} h-7 w-7 border transition-all  rounded-sm p-1.5`,
                        })}
                        {item.name}
                      </a>
                    </li>
                  </>
                );
              })}
            </ul>
            <h1 className='text-sm font-semibold pb-1'>Components</h1>
            <ul>
              {AllComponens?.map((link) => {
                return (
                  <>
                    <li
                      key={link.href}
                      className={`2xl:text-sm text-[0.81em]  flex items-center gap-1 dark:hover:text-white 2xl:py-1 py-0.5 pl-2 border-l transition-all ${
                        link.href === pathname
                          ? 'dark:border-white border-black text-black dark:text-white font-semibold'
                          : 'dark:text-slate-400 2xl:font-normal font-medium hover:border-black/60 dark:hover:border-white/50 text-slate-500 hover:text-slate-900'
                      }`}
                      // data-active={link.id === pathname}
                    >
                      <Link href={link.href}>{link.componentName}</Link>
                      {link?.isAlert && (
                        <span className='2xl:text-xs text-[0.74em] bg-blue-500 text-white px-1 rounded'>
                          {link?.isAlert}
                        </span>
                      )}
                    </li>
                  </>
                );
              })}
            </ul>
          </ScrollArea>
        </DrawerContent>
      </SidebarDrawer>
    </>
  );
}

export default MobileHeader;
