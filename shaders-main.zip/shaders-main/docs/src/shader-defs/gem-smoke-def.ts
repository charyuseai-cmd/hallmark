import { gemSmokePresets } from '@paper-design/shaders-react';
import type { ShaderDef } from './shader-def-types';
import { animatedImageCommonParams } from './common-param-def';

const defaultParams = gemSmokePresets[0].params;

export const gemSmokeDef: ShaderDef = {
  name: 'Gem Smoke',
  description: 'Fluid, smoke shape animating behind the input image and being distorted by shape',
  params: [
    {
      name: 'image',
      type: 'HTMLImageElement | string',
      description: 'An optional image used as an effect mask. A transparent background is required.',
    },
    {
      name: 'shape',
      type: 'enum',
      defaultValue: defaultParams.shape,
      description: 'The predefined shape used as an effect mask (needs no image)',
      options: ['none', 'circle', 'daisy', 'diamond', 'metaballs'],
    },
    {
      name: 'colors',
      type: 'string[]',
      defaultValue: [],
      isColor: true,
      description: 'Up to 6 colors',
    },
    {
      name: 'colorBack',
      type: 'string',
      defaultValue: defaultParams.colorBack,
      isColor: true,
      description: 'Background color',
    },
    {
      name: 'innerDistortion',
      type: 'number',
      min: 0,
      max: 1,
      defaultValue: defaultParams.innerDistortion,
      description: 'The power of smoke distortion inside the input shape (shape defined by alpha channel), needs innerGlow > 0',
    },
    {
      name: 'outerDistortion',
      type: 'number',
      min: 0,
      max: 1,
      defaultValue: defaultParams.outerDistortion,
      description: 'The power of smoke distortion outside the input shape (shape defined by alpha channel), needs outerGlow > 0',
    },
    {
      name: 'outerGlow',
      type: 'number',
      min: 0,
      max: 1,
      defaultValue: defaultParams.outerGlow,
      description: 'The visibility of smoke shape out of the input shape (shape defined by alpha channel)',
    },
    {
      name: 'innerGlow',
      type: 'number',
      min: 0,
      max: 1,
      defaultValue: defaultParams.innerGlow,
      description: 'The visibility of smoke shape inside the input shape (shape defined by alpha channel)',
    },
    {
      name: 'colorInner',
      type: 'string',
      defaultValue: defaultParams.colorInner,
      isColor: true,
      description: 'Additional color inside the input shape, mixing with smoke',
    },
    {
      name: 'offset',
      type: 'number',
      min: -1,
      max: 1,
      defaultValue: defaultParams.offset,
      description: 'Vertical offset of smoke inside the shape (needs innerGlow > 0)',
    },
    {
      name: 'angle',
      type: 'number',
      min: 0,
      max: 360,
      defaultValue: defaultParams.angle,
      description: 'Smoke direction',
    },
    {
      name: 'size',
      type: 'number',
      min: 0,
      max: 1,
      defaultValue: defaultParams.size,
      description: 'The size of smoke shape relative to the image box',
    },
    ...animatedImageCommonParams,
  ],
};
