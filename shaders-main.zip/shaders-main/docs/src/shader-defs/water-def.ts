import { waterPresets } from '@paper-design/shaders-react';
import type { ShaderDef } from './shader-def-types';
import { animatedImageCommonParams } from './common-param-def';

const defaultParams = waterPresets[0].params;

export const waterDef: ShaderDef = {
  name: 'Water',
  description:
    'Water-like surface distortion with natural caustic realism. Works as an image filter or standalone animated texture.',
  params: [
    {
      name: 'image',
      type: 'HTMLImageElement | string',
      description: 'The image to use for the effect',
    },
    {
      name: 'colorBack',
      type: 'string',
      defaultValue: defaultParams.colorBack,
      isColor: true,
      description: 'Background color',
    },
    {
      name: 'colorHighlight',
      type: 'string',
      defaultValue: defaultParams.colorHighlight,
      isColor: true,
      description: 'Highlight color (needs highlights > 0)',
    },
    {
      name: 'highlights',
      type: 'number',
      min: 0,
      max: 1,
      defaultValue: defaultParams.highlights,
      description:
        'A coloring added over the image/background, following the caustic shape (needs colorHighlight alpha > 0)',
    },
    {
      name: 'layering',
      type: 'number',
      min: 0,
      max: 1,
      defaultValue: defaultParams.layering,
      description: 'The power of 2nd layer of caustic distortion (needs caustic or highlights > 0)',
    },
    {
      name: 'edges',
      type: 'number',
      min: 0,
      max: 1,
      defaultValue: defaultParams.edges,
      description: 'Caustic distortion power on the image edges (needs image and caustic > 0)',
    },
    {
      name: 'waves',
      type: 'number',
      min: 0,
      max: 1,
      defaultValue: defaultParams.waves,
      description: 'Additional distortion based in simplex noise, independent from caustic',
    },
    {
      name: 'caustic',
      type: 'number',
      min: 0,
      max: 1,
      defaultValue: defaultParams.caustic,
      description: 'Power of caustic distortion (needs image)',
    },
    {
      name: 'size',
      type: 'number',
      min: 0.01,
      max: 7,
      defaultValue: defaultParams.size,
      description: 'Pattern scale relative to the image',
    },
    ...animatedImageCommonParams,
  ],
};
