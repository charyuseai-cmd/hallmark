/// <reference types="@webgpu/types" />
